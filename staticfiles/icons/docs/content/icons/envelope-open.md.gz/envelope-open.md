---
title: Envelope open
categories:
  - Communications
tags:
  - email
  - message
  - mail
  - letter
---

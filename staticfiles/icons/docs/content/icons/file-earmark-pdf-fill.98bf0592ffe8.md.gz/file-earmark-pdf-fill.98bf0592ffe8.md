---
title: File earmark PDF fill
categories:
  - Files and folders
tags:
  - doc
  - document
  - adobe
  - acrobat
---

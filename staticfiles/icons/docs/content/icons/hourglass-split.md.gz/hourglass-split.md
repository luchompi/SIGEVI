---
title: Hourglass split
categories:
  - Real world
tags:
  - time
  - history
  - wait
  - sand
  - clock
---

---
title: Person badge
categories:
  - People
tags:
  - human
  - individual
  - avatar
  - user
  - badge
  - id
  - card
  - account
---

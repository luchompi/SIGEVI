---
title: Receipt
layout: icon
categories:
  - Commerce
tags:
  - receipt
  - invoice
  - sale
  - purchase
  - bill
---
